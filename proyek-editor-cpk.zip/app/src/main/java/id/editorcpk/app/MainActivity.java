package id.editorcpk.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int PICK = 1;
    private static final int SAVE = 2;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private OutputStream out;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        // layar tetap menyala agar proses file besar tidak terputus
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowContentAccess(true);
        web.addJavascriptInterface(new Saver(), "AndroidSaver");
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                        params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(i, PICK);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK && fileCallback != null) {
            Uri[] uris = null;
            if (result == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null) {
                    uris = new Uri[clip.getItemCount()];
                    for (int i = 0; i < uris.length; i++) uris[i] = clip.getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    uris = new Uri[]{data.getData()};
                }
            }
            fileCallback.onReceiveValue(uris);
            fileCallback = null;
        } else if (request == SAVE) {
            boolean ok = false;
            if (result == RESULT_OK && data != null && data.getData() != null) {
                try {
                    OutputStream raw = getContentResolver().openOutputStream(data.getData(), "wt");
                    if (raw != null) {
                        out = new BufferedOutputStream(raw, 1 << 20);
                        ok = true;
                    }
                } catch (IOException | SecurityException e) {
                    ok = false;
                }
            }
            web.evaluateJavascript("window.__saveReady && window.__saveReady(" + ok + ")", null);
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // jangan buang pekerjaan; cukup pindah ke latar belakang
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        close();
        web.destroy();
        super.onDestroy();
    }

    private synchronized boolean close() {
        if (out == null) return false;
        try {
            out.close();
            return true;
        } catch (IOException e) {
            return false;
        } finally {
            out = null;
        }
    }

    /** Dipanggil dari JavaScript untuk menulis file hasil sedikit demi sedikit. */
    private class Saver {
        @JavascriptInterface
        public void start(final String name) {
            runOnUiThread(() -> {
                close();
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/octet-stream");
                i.putExtra(Intent.EXTRA_TITLE, name);
                try {
                    startActivityForResult(i, SAVE);
                } catch (ActivityNotFoundException e) {
                    web.evaluateJavascript("window.__saveReady && window.__saveReady(false)", null);
                }
            });
        }

        @JavascriptInterface
        public boolean write(String base64) {
            synchronized (MainActivity.this) {
                if (out == null) return false;
                try {
                    out.write(Base64.decode(base64, Base64.DEFAULT));
                    return true;
                } catch (IOException | IllegalArgumentException e) {
                    return false;
                }
            }
        }

        @JavascriptInterface
        public boolean finish() {
            return close();
        }

        @JavascriptInterface
        public void abort() {
            close();
        }
    }
}
